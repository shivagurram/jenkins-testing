kubectl create -f namespace_prod.yaml
kubectl create -f namespace_staging.yaml
kubectl create -f service_prod.yaml
kubectl create -f service_staging.yaml
